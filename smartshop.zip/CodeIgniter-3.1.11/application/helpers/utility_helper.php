<?php

function asset(){
	return base_url.'assets/';
}
?>