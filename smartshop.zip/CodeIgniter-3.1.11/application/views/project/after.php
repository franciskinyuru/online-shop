<div id="after sale" style="margin-top: 2vh;" >
	<div class="container">
		<div  class="row">
			<div class="col-sm-12 col-lg-4 col-md-4">
				<img class="col-sm-12 col-lg-12 col-md-12" src="<?php $this->load->helper('url');echo base_url();?>assets/images/cart26.jpg">
			</div>
			<div class="col-sm-12 col-lg-8 col-md-8">
				<p><strong>After sale services</strong><br>
					We offer free delivery to our customers who purchase goods amountin to ksh 5000.<br>
					For goods below this price we charge ksh 250.
				</p>
			</div>
		</div>
	</div>
	
</div>