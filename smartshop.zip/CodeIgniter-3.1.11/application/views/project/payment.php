<div id="payment">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-lg-4 col-md-4">
			<img class="col-sm-12 col-md-12 col-lg-12" src="<?php $this->load->helper('url');echo base_url();?>assets/images/paypesa.jpg">
			</div>
			<div class="col-sm-12 col-lg-8 col-md-8">
			<p ><strong>Our Payment Methods</strong></p>
			<p class="lead"><strong>Mpesa</strong>
				<br>Pay via mpesa to till number 33344466.</p>
				<p class="lead"><strong>Paypal</strong><br>
				electronic payment via paypal</p>
				<p class="lead"><strong>Visa Card/debit card</strong><br>
					You can also pay via mastercard or use of debit card

				</p>
			</div>
		</div>
	</div>
</div>