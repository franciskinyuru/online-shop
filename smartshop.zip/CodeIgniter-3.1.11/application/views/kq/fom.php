<!DOCTYPE html>
<html>
<head>
	<title>my form</title>
</head>
<body>
<?php //echo validation_errors();?>
<?php// echo form_open('form');?>
<label>Username</label>
<input type="text" name="username" size="50">
<label>Password</label>
<input type="text" name="password" size="50">
<label>Password Confirm</label>
<input type="text" name="passconf" size="50">
<label>Email Address</label>
<input type="text" name="email" size="50">
<div><input type="submit" name="submit"></div>
</form>
</body>
</html>