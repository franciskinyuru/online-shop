<!DOCTYPE html>
<html>
<head>
	<title>my form</title>
</head>
<body>
<h3>Your form was successfully submitted</h3>
<p><?php echo anchor('form','try it again');?></p>
</body>
</html>