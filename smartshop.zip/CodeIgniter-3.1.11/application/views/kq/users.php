<?php
$que=$data;
//print_r($que);
?>
<!DOCTYPE html>
<html>
<head>
	<title>kenya airways </title>
	<link rel="stylesheet" type="text/css" href="css/css/bootstrap.css">
</head>
<body>

<table id="tb11" class="table">
	<caption>kenya airways employees</caption>
	<tr>
		<th>username</th>
		<th>password</th>
		<th colspan="2">action</th>

	</tr>
<?php
foreach ($que as $key => $value) {
	?>
<tr> <td><?php echo $value['name'];?></td> <td><?php echo $value['password'];?></td>
<td><button ><a onclick="return confirm('are you sure you want to delete?')" 
	href="loads?id=<?php echo $value['id']?>">delete</a></button></td>
<td><button  onclick="
document.getElementById('tb11').style.width='60%';
var s=document.getElementsByClassName('main');
for (var i = s.length - 1; i >= 0; i--) {
	s[i].style.display='none';
}
document.getElementById('<?php echo $value['id'];?>').style.display='block'; " >edit</button></td>

</tr>
<div class="main" id="<?php echo $value['id'];?>" style="display: none;">
	<form action="update_data" method="post">
	<p>Edit details here</p>
	<label>employee Id</label><br>
	<input type="text" name="id" readonly="" value="<?php echo $value['id']; ?>"><br>
	<label>Username</label><br>
	<input type="text" name="user" required=""  value="<?php echo $value['name']; ?>"><br>
	<label>Password</label><br>
	<input type="text" name="password" required=""  value="<?php echo $value['password']; ?>"><br>
	<button type="submit" name="submit">submit</button>
</form>
</div>
	<?php
}
?>
</table>

</body>
</html>
<style type="text/css">
.main{
	width: 30%;
position: relative;
float: left;
background-color: #ccffff
}
	.main form{
		width: 50%;
		margin-left: auto;
		margin-right: auto;
		background-color: #ccffff;
	}
	.main input,label{
		width: 90%;
		border-radius: 7px;
		height: 2vh;
		margin: 2vh;
	}
	.main button{
		width: 20%;
		border-radius: 5px;
		margin-bottom: 2vh;
	}

	#tb11{
background-color:white;
width: 96%;
float: right;
margin-left: 2%;
margin-right: 2%;
column-width: 16%;

	}
	td,th{
		border: 1px solid green;
		width: 16%;
		background-color:white;
		border-spacing: 0px; 
		font-size: 17px;
	font-family: monospace;



	}
	tr{
		border: solid;
	}
</style>