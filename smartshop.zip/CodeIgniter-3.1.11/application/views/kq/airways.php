<link rel="stylesheet" type="text/css" href="<?php $this->load->helper('url');echo base_url();?>assets/css/bootstrap.min.css">
<?php echo base_url();?>
<script type="text/javascript" src="<?php $this->load->helper('url');echo base_url();?>js/"> </script>
<form action="datas" method="post">
	<input type="text" name="user" required="">
<input type="password" name="password" required="">
<input type="submit" name="submit" value="submit">
<button class="btn-success" id="me">csjc,jsc,scs,c</button>
</form>