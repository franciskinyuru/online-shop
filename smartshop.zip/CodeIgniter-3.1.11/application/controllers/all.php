<?php
class all extends CI_Controller{
	function inserts(){
		$this->load->view('kq/airways');
	}
	function datas(){
		$this->load->model('queries/connect');
	$que=$this->connect->entry();
	if ($que) {
	echo "success";
	header("location:loads");
	}
	else{
		echo "failed";
	}
	}
	function loads(){
		$this->load->model('queries/connect');
	$que['data']=$this->connect->getall();
	$this->load->helper('url');
	$this->load->view('kq/users.php',$que);
	if (isset($_GET['id'])) {
		$id=$_GET['id'];
		?>
		<script type="text/javascript">
			alert('corona');
			
		</script>
		<?php
		$que=$this->connect->removes($id);
		?>
		<script type="text/javascript">
			alert('<?php echo($que)?>');
			location.href='loads';
		</script>
		<?php

	}
	}
	function update_data(){
			$this->load->model('queries/connect');
	$que=$this->connect->updating();
	$this->load->helper('url');
	if ($que) {
		?>
<script type="text/javascript">
	alert("data updated successfully");
	location.href='loads';
</script>
		<?php
	}
	}
}
?>