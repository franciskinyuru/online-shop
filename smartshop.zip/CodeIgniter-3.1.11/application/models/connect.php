<?php
class connect extends CI_Model{

	function entry(){
		$this->load->database("default",FALSE);
		$inser=array( "name"=>$this->input->post("user"), "password"=>$this->input->post("password")
		);
		
$sql=$this->db->insert("zalego",$inser);
return $sql;

	}
}
?>