<?php
class connect extends CI_Model{

	function entry(){
		$this->load->database("default",FALSE);
		$inser=array( "name"=>$this->input->post("user"), "password"=>$this->input->post("password")
		);
		
$sql=$this->db->insert("bio",$inser);
return $sql;

	}
	function getall(){
		$this->load->database("default",FALSE);
		$sql=$this->db->query("select * from bio");
		return $sql->result_array();
	}
	function updating(){
		$this->load->database("default",FALSE);
		$inser=array( "name"=>$this->input->post("user"), "password"=>$this->input->post("password")
		);
		$id="id=".$this->input->post('id');
		$sql=$this->db->update('bio',$inser,$id);
		if ($sql) {
		return true;	
		}
		else{
			return false;
		}
	}
	function removes($id){
     $this->load->database("default",FALSE);
        $sql=$this->db->query("delete from bio where id='$id'");
        if ($sql) {
        	echo "deleted succefully";
        }else{
        	echo "failed to delete";
        }

	}
}
?>